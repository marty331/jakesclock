from wtforms_components import StringField

from tests import FieldTestCase


class TestStringField(FieldTestCase):
    field_class = StringField
