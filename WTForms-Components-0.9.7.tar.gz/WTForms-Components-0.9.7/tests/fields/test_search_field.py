from wtforms_components import SearchField

from tests import FieldTestCase


class TestSearchField(FieldTestCase):
    field_class = SearchField
