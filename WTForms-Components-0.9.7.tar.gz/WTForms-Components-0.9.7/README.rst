WTForms-Components
==================

|Build Status| |Version Status| |Downloads|

Additional fields, validators and widgets for WTForms.


Resources
---------

- `Documentation <http://wtforms-components.readthedocs.org/>`_
- `Issue Tracker <http://github.com/kvesteri/wtforms-components/issues>`_
- `Code <http://github.com/kvesteri/wtforms-components/>`_

.. |Build Status| image:: https://travis-ci.org/kvesteri/wtforms-components.png?branch=master
   :target: https://travis-ci.org/kvesteri/wtforms-components
.. |Version Status| image:: https://pypip.in/v/WTForms-Components/badge.png
   :target: https://crate.io/packages/WTForms-Components/
.. |Downloads| image:: https://pypip.in/d/WTForms-Components/badge.png
   :target: https://crate.io/packages/WTForms-Components/
